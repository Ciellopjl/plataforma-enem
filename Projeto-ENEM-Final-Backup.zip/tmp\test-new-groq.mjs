import { createGroq } from "@ai-sdk/groq";
import { generateText } from "ai";

// Sênior: Testando a NOVA chave enviada pelo usuário
const apiKey = "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";

async function test() {
  const groq = createGroq({ apiKey });

  try {
    console.log("--- TESTANDO NOVA CHAVE GROQ ---");
    const { text } = await generateText({
      model: groq("llama-3.3-70b-versatile"),
      prompt: "Responda apenas 'CONECTADO' se estiver funcionando.",
    });
    console.log("RESULTADO:", text);
  } catch (e) {
    console.error("ERRO NO TESTE:", e.message);
  }
}

test();
