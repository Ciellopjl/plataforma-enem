import http from 'https';

const options = {
  hostname: 'api.x.ai',
  port: 443,
  path: '/v1/models',
  method: 'GET',
  headers: {
    'Authorization': 'Bearer xai-IhapZ5oYZMe0lVtSveHXcV0mOYjd0VdhR1q8PfrvMu6fBoHut7LxjcW7rmQPDaVzvM2cLL2wIIjASyuR',
    'Content-Type': 'application/json'
  }
};

const req = http.request(options, (res) => {
  let data = '';
  res.on('data', (chunk) => data += chunk);
  res.on('end', () => {
    console.log('STATUS:', res.statusCode);
    try {
      const json = JSON.parse(data);
      console.log('MODELOS DISPONÍVEIS:', JSON.stringify(json, null, 2));
    } catch (e) {
      console.log('RESPOSTA RAW:', data);
    }
  });
});

req.on('error', (e) => console.error('ERRO:', e));
req.end();
